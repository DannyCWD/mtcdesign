
<?php 
    $footerinfo = get_field('footer_info');
    $smfacebook = get_field('smfacebook');
    $smtwitter = get_field('smtwitter');
    $sminstagram = get_field('sminstagram');
    ?>

<footer class="container-fluid">
    <div class="container p-0">
        <div class="row py-4">
            <div class="col-12 my-4 p-0 mx-0">
                <img src="/mtcmedia/wp-content/uploads/2021/01/logo-line-tp.png" class="img-fluid d-none d-md-block"alt="">
                <img src="/mtcmedia/wp-content/uploads/2021/01/logo.png" class="img-fluid d-block d-md-none m-auto" alt="">
            </div>
        </div>
        <div class="row">
            <?php if( have_rows('about') ): ?>
            <div class="col-6 col-md-2 offset-md-2 p-0">
                <p class="mb-4">About</p>
                <ul>
                    <?php while( have_rows('about') ): the_row(); 
                    $link = get_sub_field('link');
                    $text = get_sub_field('text');
                    ?>
                    <li>
                        <?php if ($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>"><?php echo $text; ?></a>
                        <?php endif; ?>
                    </li>
                    <?php endwhile; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if( have_rows('service') ): ?>
            <div class="col-6 col-md-2 px-2">
                <p class="mb-4">Service</p>
                <ul>
                    <?php while( have_rows('service') ): the_row(); 
                    $link = get_sub_field('link');
                    $text = get_sub_field('text');
                    ?>
                    <li>
                        <?php if ($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>"><?php echo $text; ?></a>
                        <?php endif; ?>
                    </li>
                    <?php endwhile; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if( have_rows('info') ): ?>
            <div class="col-6 col-md-2 px-2">
                <p class="mb-4">Info</p>
                <ul>
                    <?php while( have_rows('info') ): the_row(); 
                    $link = get_sub_field('link');
                    $text = get_sub_field('text');
                    ?>
                    <li>
                        <?php if ($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>"><?php echo $text; ?></a>
                        <?php endif; ?>
                    </li>
                    <?php endwhile; ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="col-6 col-md-2 px-2">
                <p class="mb-4">Follow</p>
                <p><img src="<?php echo $smfacebook['url']; ?>" alt="<?php echo $smfacebook['alt']; ?>" class="mr-3"/><img src="<?php echo $smtwitter['url']; ?>" alt="<?php echo $smtwitter['alt']; ?>" class="mr-3"/><img src="<?php echo $sminstagram['url']; ?>" alt="<?php echo $sminstagram['alt']; ?>"/></p>
            </div>
        </div>
        <div class="row py-4">
            <div class="col-12 col-md-6 offset-md-3">
                <p class="small-grey text-center"><?php echo $footerinfo; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-12 mb-3 p-0">
                <img src="/mtcmedia/wp-content/uploads/2021/01/line-tp.png" class="img-fluid" alt="">
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
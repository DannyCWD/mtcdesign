<?php get_header(); ?>

    <?php get_template_part('includes/section','hero');?>

    <?php get_template_part('includes/section','aboutus');?>

    <?php get_template_part('includes/section','faq');?>

    <?php get_template_part('includes/section','gallery');?>

<?php get_footer(); ?>
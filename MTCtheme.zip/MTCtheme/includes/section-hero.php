<?php
    $hero1 = get_field('hero1');
    $logo = get_field('logo');
    $subtitle = get_field('subtitle');
    $title = get_field('title');
    $link = get_field('link');
    $linktext = get_field('link_text');
    ?>
    
    <?php if( !empty($hero1) ): ?>
    <section id="hero">
        <div id="carouselHeroIndicators" class="carousel slide" data-ride="carousel">
            <div class="w-100" style="position: absolute; z-index: 10">
                <div class="container px-0">
                    <div class="row py-0 pt-md-3 pb-md-4 hr">
                        <nav class="navbar navbar-expand-lg navbar-light bg-ghost w-100 px-0">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">  
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse mynavbg" id="navbarTogglerDemo01">
                                <div class="container p-0 m-0">
                                    <div class="col-12 p-0 m-0">
                                        <div class="row text-center">
                                            <div class="col-12 col-lg-5 p-0 m-0">
                                                <ul class="navbar-nav">
                                                    <li class="nav-item pt-0 pt-lg-1">
                                                        <a class="nav-link" href="#"><i class="fa fa-facebook"></i></a>
                                                    </li>
                                                    <li class="nav-item pt-0 pt-lg-1">
                                                        <a class="nav-link" href="#"><i class="fa fa-twitter"></i></a>
                                                    </li>
                                                    <li class="nav-item mr-0 mr-lg-4 pt-0 pt-lg-1">
                                                        <a class="nav-link" href="#"><i class="fa fa-instagram"></i></a>
                                                    </li>
                                                    <li class="nav-item ml-0 ml-lg-4">
                                                        <a class="nav-link mybutton-noborder text-primary" href="#">Shop</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link mybutton-noborder text-primary" href="#">Plan My Kitchen</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-12 col-lg-2 d-none d-lg-block">
                                                <ul class="navbar-nav d-flex justify-content-center">
                                                    <li class="nav-item active">
                                                        <a class="nav-link" href="#"><img src="<?php echo $logo['url']; ?>" alt=""></a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-12 col-lg-5 p-0 m-0">
                                                <ul class="navbar-nav d-flex justify-content-end">
                                                    <li class="nav-item">
                                                        <a class="nav-link mybutton-noborder text-primary" href="#">About Us</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link mybutton-noborder text-primary" href="#">Gallery</a>
                                                    </li>
                                                    <li class="nav-item ml-0 ml-lg-4 mb-3 mb-lg-0">
                                                        <a class="nav-link mymenubutton mymenubutton--border" href="#">My Order</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>              
                                </div>
                            </div>
                        </nav>
                    </div> 
                </div>
            </div>
            <ul class="carousel-indicators carousel-indicators--sand">
                <li data-target="#carouselHeroIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselHeroIndicators" data-slide-to="1"></li>
                <li data-target="#carouselHeroIndicators" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner" style="z-index:1">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo $hero1['url']; ?>" alt="First slide">
                    <div class="carousel-caption carousel-caption--centercontent carousel-caption--adjusthero">
                        <h6 class="text-light"><?php echo $subtitle; ?></h6>
                        <h2 class="hero fs52"><?php echo $title; ?></h2>
                        <?php if($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>" class="mybutton mybutton--bgsand mybutton--big"><?php echo $linktext; ?></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="carousel-item"  style="z-index:1">
                    <img class="d-block w-100" src="<?php echo $hero1['url']; ?>" alt="Second slide">
                    <div class="carousel-caption carousel-caption--centercontent carousel-caption--adjusthero">
                        <h6 class="text-light"><?php echo $subtitle; ?></h6>
                        <h2 class="hero fs52"><?php echo $title; ?></h2>
                        <?php if($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>" class="mybutton mybutton--bgsand mybutton--big"><?php echo $linktext; ?></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="carousel-item" style="z-index:1">
                    <img class="d-block w-100" src="<?php echo $hero1['url']; ?>" alt="Third slide">
                    <div class="carousel-caption carousel-caption--centercontent carousel-caption--adjusthero">
                        <h6 class="text-light"><?php echo $subtitle; ?></h6>
                        <h2 class="hero fs52"><?php echo $title; ?></h2>
                        <?php if($link['url']): ?>
                        <a href="<?php echo $link['url']; ?>" class="mybutton mybutton--bgsand mybutton--big"><?php echo $linktext; ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>      
    </section>
    <?php endif; ?>
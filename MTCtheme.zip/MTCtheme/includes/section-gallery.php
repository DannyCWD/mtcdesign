<?php 
    $gtitle = get_field('gtitle');
    $gbutton = get_field('gbutton');
    $gbuttonlink = get_field('gbutton_link');
    ?>

    <?php if( have_rows('images') ): ?>
    <section id="customer-gallery">
        <div class="container">
            
            <div class="row">
                <div class="col-12">
                    <h3 class="text-center mb-4 mt-5"><?php echo $gtitle; ?></h3>
                </div>
                <?php while( have_rows('images') ) : the_row();
                
                $image = get_sub_field('image');
                $image_label = get_sub_field('image_label');
                ?>
            
                <div class="col-12 col-md-3">
                    <?php if ($gbutton): ?>
                    <a href="<?php echo $gbutton; ?>"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image_label; ?>" class="img-fluid my-3 my-md-0"></a>
                    <?php endif; ?>
                </div>
            
                <?php endwhile;?>
                <div class="col-12 text-center my-5">
                    <?php if ($gbutton): ?>
                    <a class="mybutton mybutton--bgsand mybutton--big mybutton--vm mb-5" href="<?php echo $gbutton; ?>"><?php echo $gbuttonlink; ?></a>
                    <?php endif; ?>
                </div>
            </div>
            
                
            

            
            
        </div>
    </section>
    <?php endif; ?>
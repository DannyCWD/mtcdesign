    <?php 
        $lsimage = get_field('left_side_image');
        ?>
    <?php if( !empty($lsimage) ): ?>
    <section id="about-us">
        
        <div class="container-fluid p-0 m-0">
            <div class="row">
                
                <div class="col-12 col-md-6 p-0 m-0 order-2 order-md-1">
                    <img class="d-block w-100 img-cover" src="<?php echo $lsimage['url']; ?>" alt="<?php echo $lsimage['alt']; ?>">
                </div>
                
                <?php
                $rsinfo = get_field('right_side_info');
                if( $rsinfo ): 
                ?>
                <div class="col-12 col-md-6 order-1 order-md-2 d-flex flex-column justify-content-center">
                    <div class="ml-5 w-580">
                    <h6><?php echo esc_html( $rsinfo['sub_title'] ); ?></h6>
                    <h3 class="fs42"><?php echo esc_html( $rsinfo['title'] ); ?></h3>
                    <p class="fs15"><?php echo esc_html( $rsinfo['description'] ); ?></p>
                    <?php if($rsinfo['button']):?>
                    <a href="<?php echo $rsinfo['button']; ?>" class="mybutton mybutton--bgsand mybutton--big mb-5"><?php echo esc_html( $rsinfo['button_text'] ); ?></a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
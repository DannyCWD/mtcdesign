<section id="faq">
        <?php
        $faq = get_field('faq');
        if( $faq ): 
        ?>
        <div class="container-fluid p-0 m-0">
            <div class="row bg-light">
                <div class="col-12 col-lg-6 offset-lg-3 text-center">
                    <div id="carouselFAQsIndicators" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item carousel-height active">
                                <div class="carousel-caption carousel-caption--centercontent text-dark carousel-caption--adjustfaq">
                                    <h6><?php echo esc_html( $faq['sub_title'] ); ?></h6>
                                    <h3><?php echo esc_html( $faq['title'] ); ?></h3>
                                    <p class="fs18 helvetica"><?php echo esc_html( $faq['description'] ); ?></p>
                                    <p class="fs15"><?php echo esc_html( $faq['author']);?></p>
                                    <?php if ($faq['link']): ?>
                                    <a href="<?php echo esc_url( $faq['link']['link_text'] ); ?>" class="mybutton mybutton--bgsand mybutton--faq my-3"><?php echo esc_html( $faq['link_text'] ); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="carousel-item carousel-height">
                                <div class="carousel-caption carousel-caption--centercontent text-dark carousel-caption--adjustfaq">
                                    <h6><?php echo esc_html( $faq['sub_title'] ); ?></h6>
                                    <h3><?php echo esc_html( $faq['title'] ); ?></h3>
                                    <p class="fs18 helvetica"><?php echo esc_html( $faq['description'] ); ?></p>
                                    <p class="fs15"><?php echo esc_html( $faq['author']);?></p>
                                    <?php if ($faq['link']): ?>
                                    <a href="<?php echo esc_url( $faq['link']['link_text'] ); ?>" class="mybutton mybutton--bgsand mybutton--faq my-3"><?php echo esc_html( $faq['link_text'] ); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="carousel-item carousel-height">
                                <div class="carousel-caption carousel-caption--centercontent text-dark carousel-caption--adjustfaq">
                                    <h6><?php echo esc_html( $faq['sub_title'] ); ?></h6>
                                    <h3><?php echo esc_html( $faq['title'] ); ?></h3>
                                    <p class="fs18 helvetica"><?php echo esc_html( $faq['description'] ); ?></p>
                                    <p class="fs15"><?php echo esc_html( $faq['author']);?></p>
                                    <?php if ($faq['link']): ?>
                                    <a href="<?php echo esc_url( $faq['link']['link_text'] ); ?>" class="mybutton mybutton--bgsand mybutton--faq my-3"><?php echo esc_html( $faq['link_text'] ); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" style="color: red;" href="#carouselFAQsIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon"  style="color: red;" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselFAQsIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php endif; ?>